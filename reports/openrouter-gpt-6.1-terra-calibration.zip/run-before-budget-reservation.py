# Copyright 2026 Roboflow, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import hashlib
import json
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import asdict
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from PIL import Image, ImageOps

from vlm_exam.providers.openrouter import OpenRouterProvider
from vlm_exam.tasks.detection import DetectionCoordinateFormat, DetectionTask

load_dotenv("/Users/skalskip/Documents/vlm-exam/.env")
MODELS = {"gpt-6.1-terra": ("openai/gpt-6.1-terra", "openai", 1.25, 5.0)}


def options(model: str) -> dict[str, Any]:
    """Return the candidate's explicit route and reasoning settings."""
    return json.loads((ROOT / "plan.json").read_text())["options"]


ROOT = Path("experiments/terra-calibration")


def _write(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, indent=2))
    temporary.replace(path)


def _request(job: dict[str, Any]) -> dict[str, Any]:
    started = time.monotonic()
    row = dict(job)
    try:
        provider = OpenRouterProvider(
            job["model"],
            provider_model_id=MODELS[job["model"]][0],
            options=options(job["model"]),
        )
        with Image.open(job["image_path"]) as source:
            image = ImageOps.exif_transpose(source).convert("RGB")
        answer, usage, retry = provider.predict(image, job["prompt"], job["effort"])
        row.update(answer=answer, usage=asdict(usage), retry=asdict(retry))
    except Exception as error:
        row["error"] = str(error)
    row["seconds"] = time.monotonic() - started
    _write(ROOT / "responses" / (job["id"] + ".json"), row)
    return row


def _main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["diagnostic", "matrix"], required=True)
    args = parser.parse_args()
    cached_manifest = ROOT / (args.stage + "-manifest.json")
    if cached_manifest.exists():
        jobs = json.loads(cached_manifest.read_text())["jobs"]
    else:
        selections = {
            "gpt-6.1-terra": json.loads((ROOT / "plan.json").read_text())["search"][
                "formats"
            ]
        }
        samples = DetectionTask().load_samples("data/detection/train")[:50]
        jobs = []
        providers = {
            model: OpenRouterProvider(
                model, provider_model_id=MODELS[model][0], options=options(model)
            )
            for model in MODELS
        }
        for index, sample in enumerate(samples):
            for model in MODELS:
                if args.stage == "diagnostic" and (
                    model in ["muse-spark-open", "deepseek-v4.1-flash-1017"]
                    or index not in [0, 7, 14, 28, 49]
                ):
                    continue
                for effort in (
                    ["low", "high"] if args.stage == "diagnostic" else ["high"]
                ):
                    for coordinate_format in (
                        ["native"] if args.stage == "diagnostic" else selections[model]
                    ):
                        with Image.open(sample.image_path) as source:
                            image = ImageOps.exif_transpose(source).convert("RGB")
                        provider = providers[model]
                        uploaded = provider.uploaded_image_size(image) or image.size
                        if coordinate_format == "native":
                            prompt = (
                                "Detect every instance of these object classes "
                                "in the image: "
                                + ", ".join(sample.classes)
                                + ". Return the class and bounding box "
                                "for each instance. "
                                "Explain the coordinate convention you use."
                            )
                        else:
                            task = DetectionTask(
                                coordinate_format=DetectionCoordinateFormat(
                                    coordinate_format
                                )
                            )
                            prompt = task.build_prompt(sample, uploaded_size=uploaded)
                        jobs.append(
                            dict(
                                id=f"{model}__{effort}__{coordinate_format}__{index:03d}",
                                model=model,
                                effort=effort,
                                format=coordinate_format,
                                index=index,
                                prompt=prompt,
                                image_path=str(sample.image_path),
                                image_sha256=hashlib.sha256(
                                    Path(sample.image_path).read_bytes()
                                ).hexdigest(),
                                original_size=list(image.size),
                                uploaded_size=uploaded,
                                options=options(model),
                            )
                        )
    manifest = dict(
        stage=args.stage,
        jobs=jobs,
        budget_usd=15.0,
        primary_metric="map50",
        secondary_metric="map50_95",
        source_sha256={
            str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(Path("src/vlm_exam").rglob("*.py"))
        },
    )
    path = ROOT / (args.stage + "-manifest.json")
    if path.exists() and json.loads(path.read_text()) != json.loads(
        json.dumps(manifest)
    ):
        raise RuntimeError("Frozen search manifest changed")
    _write(path, manifest)
    saved = {
        p.stem: json.loads(p.read_text()) for p in (ROOT / "responses").glob("*.json")
    }
    spent = sum(
        r.get("usage", {}).get("metadata", {}).get("reported", {}).get("cost", 0) or 0
        for r in saved.values()
    )
    pending = [job for job in jobs if job["id"] not in saved]
    done = len(jobs) - len(pending)
    concurrency = 48
    status = "running"
    cooldown_until = 0.0
    active = {}
    input_calibration = json.loads((ROOT / "input-token-calibration.json").read_text())
    with ThreadPoolExecutor(max_workers=128) as pool:
        while pending or active:
            control = (
                json.loads((ROOT / "control.json").read_text())
                if (ROOT / "control.json").exists()
                else {}
            )
            target = min(128, max(1, int(control.get("concurrency", 48))))
            if time.monotonic() >= cooldown_until:
                concurrency = target
            if control.get("pause"):
                status = "paused_by_control"
            main = json.loads(
                Path("experiments/full-campaign-recovery/status.json").read_text()
            )
            aggregate_room = (
                300 - 23.756395397 - main["spent_usd"] - main["active"] * 3.0
            )
            while pending and len(active) < concurrency and status == "running":
                job = pending[0]
                _, _, price_in, price_out = MODELS[job["model"]]
                measured_input = input_calibration.get(f"{job['model']}:{job['index']}")
                input_bound = (
                    min(
                        1048576,
                        2 * measured_input + len(job["prompt"].encode("utf-8")) + 1024,
                    )
                    if measured_input
                    else 1048576
                )
                reserve = (input_bound * price_in + 65536 * price_out) / 1000000
                if spent + sum(active.values()) + reserve > min(15.0, aggregate_room):
                    if not active:
                        status = "paused_budget"
                    break
                pending.pop(0)
                active[pool.submit(_request, job)] = reserve
            if not active:
                break
            finished, _ = wait(active, timeout=1, return_when=FIRST_COMPLETED)
            for future in finished:
                active.pop(future)
                row = future.result()
                spent += (
                    row.get("usage", {})
                    .get("metadata", {})
                    .get("reported", {})
                    .get("cost", 0)
                    or 0
                )
                done += 1
                if "402" in row.get("error", ""):
                    status = "paused_funds"
                if "429" in row.get("error", ""):
                    concurrency = max(2, concurrency // 2)
                    cooldown_until = time.monotonic() + 60
                print(
                    json.dumps(
                        dict(
                            id=row["id"],
                            completed=done,
                            total=len(jobs),
                            spent_usd=spent,
                            error=row.get("error"),
                        )
                    ),
                    flush=True,
                )
            _write(
                ROOT / "status.json",
                dict(
                    stage=args.stage,
                    status=status,
                    completed=done,
                    total=len(jobs),
                    active=len(active),
                    spent_usd=spent,
                    concurrency=concurrency,
                ),
            )
    _write(
        ROOT / "status.json",
        dict(
            stage=args.stage,
            status="complete" if done == len(jobs) else status,
            completed=done,
            total=len(jobs),
            active=0,
            spent_usd=spent,
        ),
    )


if __name__ == "__main__":
    _main()
