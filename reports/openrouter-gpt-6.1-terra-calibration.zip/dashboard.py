# Copyright 2026 Roboflow, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import supervision as sv
from supervision.metrics import MeanAveragePrecision

from vlm_exam.tasks.detection import (
    DetectionCoordinateFormat,
    DetectionTask,
    parse_prediction,
)

ROOT = Path("experiments/terra-calibration")
MODELS = ["gpt-6.1-terra"]
FORMATS = {MODELS[0]: json.loads((ROOT / "plan.json").read_text())["search"]["formats"]}
samples = DetectionTask().load_samples("data/detection/train")[:50]
previous = None
while True:
    try:
        paths = sorted((ROOT / "responses").glob("*.json"))
        signature = [(str(p), p.stat().st_mtime_ns) for p in paths]
        if signature != previous:
            groups = defaultdict(list)
            for path in paths:
                row = json.loads(path.read_text())
                groups[(row["model"], row["format"], row["effort"])].append(row)
            summaries = []
            for model in MODELS:
                for fmt in FORMATS[model] + ([] if model in MODELS[:2] else ["native"]):
                    for effort in ["low", "high"] if fmt == "native" else ["high"]:
                        rows = groups[(model, fmt, effort)]
                        metric = MeanAveragePrecision()
                        errors = truncated = empty = 0
                        cost = 0
                        for row in sorted(rows, key=lambda r: r["index"]):
                            metadata = row.get("usage", {}).get("metadata", {})
                            is_error = bool(row.get("error"))
                            is_truncated = metadata.get("finish_reason") == "length"
                            is_empty = not row.get("answer", "").strip() or row.get(
                                "answer"
                            ) in ["[EMPTY RESPONSE]", "[model returned no content]"]
                            errors += int(is_error)
                            truncated += int(is_truncated)
                            empty += int(is_empty and not is_error)
                            cost += metadata.get("reported", {}).get("cost", 0) or 0
                            if fmt == "native":
                                continue
                            sample = samples[row["index"]]
                            try:
                                prediction = (
                                    sv.Detections.empty()
                                    if is_error or is_truncated or is_empty
                                    else parse_prediction(
                                        row["answer"],
                                        (sample.image_width, sample.image_height),
                                        list(sample.classes),
                                        coordinate_format=DetectionCoordinateFormat(
                                            fmt
                                        ),
                                        uploaded_wh=row["uploaded_size"],
                                    )
                                )
                            except Exception:
                                prediction = sv.Detections.empty()
                                errors += 1
                            metric.update([prediction], [sample.ground_truth])
                        scores = metric.compute() if rows and fmt != "native" else None
                        total = 5 if fmt == "native" else 50
                        summaries.append(
                            dict(
                                model=model,
                                format=fmt,
                                effort=effort,
                                completed=len(rows),
                                total=total,
                                remaining=total - len(rows),
                                errors=errors,
                                truncated=truncated,
                                empty=empty,
                                cost_usd=cost,
                                map50=float(scores.map50) if scores else None,
                                map50_95=float(scores.map50_95) if scores else None,
                                partial=len(rows) < total,
                            )
                        )
            data = dict(
                updated=datetime.now(timezone.utc).isoformat(),
                rows=summaries,
                completed=len(paths),
                total=150,
                cost_usd=sum(row["cost_usd"] for row in summaries),
            )
            temp = ROOT / "table.tmp"
            temp.write_text(json.dumps(data, indent=2))
            temp.replace(ROOT / "table.json")
            previous = signature
            print(
                json.dumps(dict(updated=data["updated"], completed=len(paths))),
                flush=True,
            )
    except Exception as error:
        print(f"Dashboard aggregation error: {error}", flush=True)
    time.sleep(5)
