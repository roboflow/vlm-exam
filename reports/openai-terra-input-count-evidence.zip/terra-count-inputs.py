# Copyright 2026 Roboflow, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json,sqlite3,hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from dotenv import load_dotenv
from PIL import Image,ImageOps
from openai import OpenAI
from vlm_exam.config import load_config
from vlm_exam.tasks import create_task
from vlm_exam.providers.openai import _png_data_url
from vlm_exam.providers.image_upload import resize_image_to_max_edge
from vlm_exam.text_benchmark import inference_hash

load_dotenv('/Users/skalskip/Documents/vlm-exam/.env')
root=Path('experiments/terra-full')
manifest=json.loads((root/'manifest.json').read_text())
model=load_config().models['gpt-6.1-terra']
client=OpenAI(base_url='https://api.openai.com/v1',max_retries=2,timeout=60)
output=Path('experiments/terra-input-counts.json')
counts=json.loads(output.read_text())['counts'] if output.exists() else {}
requests={}
for name in ('detection','text'):
 args={'coordinate_format':model.detection_coordinate_format}
 if name=='text':args['inference_hash']=inference_hash(model)
 task=create_task(name,**args)
 for index,sample in enumerate(task.load_samples('data/'+name+'/train')):
  for effort in ('low','high'):
   key=f'gpt-6.1-terra:{name}:{effort}:{index}'
   requests[key]=(task,sample,effort)
def count(key: str) -> tuple[str,dict]:
 task,sample,effort=requests[key]
 im=resize_image_to_max_edge(ImageOps.exif_transpose(Image.open(sample.image_path)).convert('RGB'),2048)
 request={'model':'gpt-6.1-terra','reasoning':{'effort':effort},'input':[{'role':'user','content':[{'type':'input_image','image_url':_png_data_url(im)},{'type':'input_text','text':task.build_prompt(sample,uploaded_size=im.size)}]}]}
 result=client.responses.input_tokens.count(**request)
 return key,{'input_tokens':result.input_tokens,'request_sha256':hashlib.sha256(json.dumps(request,sort_keys=True).encode()).hexdigest()}
def save() -> None:
 temp=output.with_suffix('.tmp')
 temp.write_text(json.dumps({'datasets':manifest['datasets'],'models':manifest['models'],'code':manifest['code'],'source':'https://developers.openai.com/api/docs/guides/token-counting','counts':counts},indent=2));temp.replace(output)
with ThreadPoolExecutor(max_workers=16) as pool:
 futures=[pool.submit(count,key) for key in requests if key not in counts]
 for future in as_completed(futures):
  try:
   key,value=future.result()
  except Exception as error:
   print(type(error).__name__,str(error),flush=True);continue
  counts[key]=value;save()
  if len(counts)%50==0:print(len(counts),'/',len(requests),flush=True)
print('Complete',len(counts),'maximum input tokens',max(v['input_tokens'] for v in counts.values()),flush=True)
