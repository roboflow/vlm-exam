# Copyright 2026 Roboflow, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
import json
from pathlib import Path
from dotenv import load_dotenv
from vlm_exam.config import load_config
from vlm_exam.campaign import CampaignStore, _evaluate
from vlm_exam.judge import Judge
from vlm_exam.tasks import create_task
from vlm_exam.text_benchmark import inference_hash

load_dotenv("/Users/skalskip/Documents/vlm-exam/.env")
root = Path("experiments/terra-full/direct-pilot")
root.mkdir(parents=True, exist_ok=True)
model = load_config().models["gpt-6.1-terra"]
store = CampaignStore(root / "checkpoints.sqlite", {"model": asdict(model), "purpose": "direct API preflight; excluded from full results"})
judge = Judge(openrouter=True, cache_path=root / "judge-cache.json")
jobs = []
for name in ("ocr", "extraction", "counting", "identification", "reasoning", "detection", "text"):
    options = {"coordinate_format": model.detection_coordinate_format} if name in {"detection", "text"} else {}
    if name == "text": options["inference_hash"] = inference_hash(model)
    task = create_task(name, **options)
    samples = task.load_samples(str(Path("data") / name / "train"))
    selected = {}
    for index, sample in enumerate(samples):
        category = getattr(sample, "category", name)
        selected.setdefault(category, (index, sample))
    for effort in ("low", "high"):
        for category, (index, sample) in selected.items():
            identity = f"gpt-6.1-terra:{name}:{effort}:0:{index}"
            jobs.append((identity, index, sample, task, effort))
with ThreadPoolExecutor(max_workers=4) as pool:
    futures = {pool.submit(_evaluate, identity, index, sample, task, "gpt-6.1-terra", effort, model, store, judge): identity for identity, index, sample, task, effort in jobs if not store.get(identity)["result"]}
    for future in as_completed(futures):
        identity = futures[future]
        try:
            result = future.result()
            print(json.dumps({"id": identity, "status": "complete", "tokens": result.output_tokens, "accounted_usd": store.spent()}), flush=True)
        except Exception as error:
            store.save(identity, "error", str(error))
            print(json.dumps({"id": identity, "error": str(error)}), flush=True)
